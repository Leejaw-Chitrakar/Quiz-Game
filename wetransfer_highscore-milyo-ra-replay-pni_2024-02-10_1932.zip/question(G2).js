 
let questions = [
    {
        numb:1,
        question:"What does HTML stand for ?",
        answer:"HyperText Markup Language",
        options: [
         "HighText Machine Language",
         "HyperText and links Markup Language",
         "HyperText Markup Language",
         "None of these"
        ]// index:0;
    },
    {
        numb:2,
        question:"The correct sequence of HTML tags for starting a webpage is",
        answer: "HTML, Head, Title, Body",
        options:[
            "Head, Title, HTML, body",
            "HTML, Body, Title, Head",
            "HTML, Head, Title, Body",
            "HTML, Head, Title, Body"
        ]//index:1;
    },
    {
        numb:3,
        question:" which is an scripting language?",
        answer: "javascript",
        options:[
            "Ruby",
            "R",
            "Swift",
            "javascript"
        ]//index:2;
    },
    {
        numb:4,
        question:"Which of the following is designed to control the operations of a computer?",
        answer: "System Software",
        options:[
            "Application Software",
            "User",
            "System Software",
            "Utility Software"
        ]//index:3;
    },
    {
        numb:5,
        question:"what is the framework of css?",
        answer: "tailwind",
        options:[
            "tailwind",
            "angular",
            "React",
            "Mongo dl"
        ]//index:4;
    },
    {
        numb:6,
        question:"Which of the following is the smallest unit of data in a computer?",
        answer: "Bit",
        options:[
            "Nibble",
            "Bit",
            "Byte",
            "KB"
        ]//index:5;
    },
    {
        numb:7,
        question:"Which technology is used in compact disks?",
        answer: "Laser",
        options:[
            "Mechanical",
            "Electric",
            "Laser",
            "Electro Magnetic"
        ]//index:6;
    },
    {
        numb:8,
        question:"Which of the following is not a characteristic of a computer?",
        answer: "I.Q",
        options:[
            "Accuracy",
            "Versatility",
            "Diligence",
            "I.Q"
        ]//index:7;
    },
    {
        numb:9,
        question:"Which of the following language does the computer understand?",
        answer: "Binary Language",
        options:[
            "C Language",
            "Assembly Language",
            "Binary Language",
            "BASIC%"
        ]//index:8;
    },
    {
        numb:10,
        question:"Who is the father of Computers?",
        answer: "Charles Babbage",
        options:[
            "Dennis Ritchie",
            "Charles Babbage",
            "James Gosling",
            "Bjarne Stroustrup"
        ]//index:9;
    },{
        numb:11,
        question:"Which of the following devices provides the communication between a computer and the outer world?",
        answer: "I/O",
        options:[
            "Compact",
            "Drivers",
            "I/O",
            "Storage"
        ]//index:10;
    },
    {
        numb:11,
        question:"Which of the following are physical devices of a computer?",
        answer: "Hardware",
        options:[
            "System Software",
            "Package",
            "Software",
            "Hardware"
        ]//index:11;
    },
    {
        numb:13,
        question:"Which of the following can access the server?",
        answer: "Web Client",
        options:[
            "Web Client",
            "Client",
            "User",
            "Web Server"
        ]//index:12;
    },
    {
        numb:14,
        question:"Which of the following is an output device?",
        answer: "VDU",
        options:[
            "Mouse",
            "light Pen",
            "VDU",
            "Pen Drive"
        ]//index:13;
    },
    {
        numb:15,
        question:"Which of the following is the extension for Computer Application?",
        answer: ".exe",
        options:[
            ".txt",
            ".pptx",
            ".exe",
            ".xls"
        ]//index:14;
    }
];